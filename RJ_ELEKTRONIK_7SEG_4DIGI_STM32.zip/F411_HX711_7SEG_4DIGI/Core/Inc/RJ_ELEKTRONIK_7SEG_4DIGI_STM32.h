#ifndef RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H
#define RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H

#include "main.h" // Obligatoire pour récupérer les types GPIO_TypeDef, HAL, etc.
#include <stdbool.h>
#include <stdint.h>

#define A_Pin GPIO_PIN_1
#define A_GPIO_Port GPIOA
#define B_Pin GPIO_PIN_2
#define B_GPIO_Port GPIOA
#define C_Pin GPIO_PIN_3
#define C_GPIO_Port GPIOA
#define D_Pin GPIO_PIN_4
#define D_GPIO_Port GPIOA
#define E_Pin GPIO_PIN_5
#define E_GPIO_Port GPIOA
#define F_Pin GPIO_PIN_6
#define F_GPIO_Port GPIOA
#define G_Pin GPIO_PIN_7
#define G_GPIO_Port GPIOA
#define D4_Pin GPIO_PIN_3
#define D4_GPIO_Port GPIOB
#define D3_Pin GPIO_PIN_4
#define D3_GPIO_Port GPIOB
#define D2_Pin GPIO_PIN_5
#define D2_GPIO_Port GPIOB
#define D1_Pin GPIO_PIN_6
#define D1_GPIO_Port GPIOB
#define DP_Pin GPIO_PIN_7
#define DP_GPIO_Port GPIOB

typedef enum {
    COMMON_CATHODE,
    COMMON_ANODE
} DisplayType;

// Fonctions publiques simplifiées
// CORRECTION : Prend désormais en paramètre le pointeur vers l'instance du Timer
void SevenSeg_Init(DisplayType type, TIM_HandleTypeDef *htim);

void SevenSeg_UpdateNumber(int16_t number, bool point_on, uint8_t point_pos);
void SevenSeg_Mux_Callback(void);
void SevenSeg_Clear(void);

#endif
