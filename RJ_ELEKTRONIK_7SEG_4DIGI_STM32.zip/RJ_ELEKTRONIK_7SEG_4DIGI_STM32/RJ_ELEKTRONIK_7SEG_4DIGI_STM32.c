/**
 * @file RJ_ELEKTRONIK_7SEG_4DIGI_STM32.c
 * @brief Version ultra-simplifiée basée sur les #define matériels fixes
 */

#include "RJ_ELEKTRONIK_7SEG_4DIGI_STM32.h"

static DisplayType displayType;
static uint8_t displayDigits[4] = {11, 11, 11, 11}; 
static bool dpState[4] = {false, false, false, false}; 
static uint8_t currentDigitIndex = 0;               

static const uint8_t digitPatterns[12] = {
    0b00111111, // 0 (A,B,C,D,E,F allumés) -> Corrigé pour correspondre à l'ordre standard A=bit0...G=bit6
    0b00000110, // 1 (B,C)
    0b00111101, // 2 (A,B,G,E,D)
    0b01001111, // 3 (A,B,G,C,D)
    0b01100110, // 4 (F,G,B,C)
    0b01101101, // 5 (A,F,G,C,D)
    0b01111101, // 6 (A,F,G,C,D,E)
    0b00000111, // 7 (A,B,C)
    0b01111111, // 8 (Tous allumés)
    0b01101111, // 9 (A,B,C,D,F,G)
    0b01000000, // 10 = '-' (G allumé)
    0b00000000  // 11 = Vide
};

// Écrit un état sur un segment en gérant l'inversion anode/cathode
static void WriteSegment(GPIO_TypeDef* port, uint16_t pin, bool state) {
    if (displayType == COMMON_ANODE) {
        state = !state;
    }
    HAL_GPIO_WritePin(port, pin, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

// Écrit un état sur un digit en gérant l'inversion anode/cathode
static void WriteDigit(GPIO_TypeDef* port, uint16_t pin, bool state) {
    if (displayType == COMMON_ANODE) {
        state = !state;
    }
    // Cathode commune active le digit à l'état BAS (0V). L'ancienne version faisait l'inverse mais l'anode commune fournit le 3.3V, la cathode commune fournit la masse.
    HAL_GPIO_WritePin(port, pin, state ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static void DisplayDigit(uint8_t digit) {
    digit = (digit > 11) ? 11 : digit;
    uint8_t pattern = digitPatterns[digit];

    WriteSegment(A_GPIO_Port, A_Pin, (pattern & 0x01));
    WriteSegment(B_GPIO_Port, B_Pin, (pattern & 0x02));
    WriteSegment(C_GPIO_Port, C_Pin, (pattern & 0x04));
    WriteSegment(D_GPIO_Port, D_Pin, (pattern & 0x08));
    WriteSegment(E_GPIO_Port, E_Pin, (pattern & 0x10));
    WriteSegment(F_GPIO_Port, F_Pin, (pattern & 0x20));
    WriteSegment(G_GPIO_Port, G_Pin, (pattern & 0x40));
}

static void SelectDigit(uint8_t position) {
    // Éteint d'abord tous les digits (état inactif = false)
    WriteDigit(D1_GPIO_Port, D1_Pin, false);
    WriteDigit(D2_GPIO_Port, D2_Pin, false);
    WriteDigit(D3_GPIO_Port, D3_Pin, false);
    WriteDigit(D4_GPIO_Port, D4_Pin, false);

    // Allume le bon digit (état actif = true)
    if (position == 0) WriteDigit(D1_GPIO_Port, D1_Pin, true);
    if (position == 1) WriteDigit(D2_GPIO_Port, D2_Pin, true);
    if (position == 2) WriteDigit(D3_GPIO_Port, D3_Pin, true);
    if (position == 3) WriteDigit(D4_GPIO_Port, D4_Pin, true);
}

void SevenSeg_Init(DisplayType type) {
    displayType = type;
    
    // Note : L'initialisation des broches GPIO (HAL_GPIO_Init) est déjà faite automatiquement 
    // par le code généré par CubeMX (MX_GPIO_Init() dans main.c). Pas besoin de la refaire ici !
    
    SevenSeg_Clear();
}

void SevenSeg_UpdateNumber(int16_t number, bool point_on, uint8_t point_pos) {
    for(uint8_t i = 0; i < 4; i++) dpState[i] = false;

    if (number < 0) {
        displayDigits[0] = 10; // '-'
        number = -number;
        if (number > 999) number = 999;
        displayDigits[1] = (number / 100) % 10;
        displayDigits[2] = (number / 10) % 10;
        displayDigits[3] = number % 10;
    } 
    else if (number > 9999) {
        for (uint8_t i = 0; i < 4; i++) displayDigits[i] = 10; // '----'
    } 
    else {
        displayDigits[0] = (number / 1000) % 10;
        displayDigits[1] = (number / 100) % 10;
        displayDigits[2] = (number / 10) % 10;
        displayDigits[3] = number % 10;
    }

    if (point_on && point_pos < 4) {
        dpState[point_pos] = true;
    }
}

void SevenSeg_Mux_Callback(void) {
    SelectDigit(4); // Éteint tout pour éviter l'effet fantôme

    DisplayDigit(displayDigits[currentDigitIndex]);
    WriteSegment(DP_GPIO_Port, DP_Pin, dpState[currentDigitIndex]);

    SelectDigit(currentDigitIndex);
    currentDigitIndex = (currentDigitIndex + 1) % 4;
}

void SevenSeg_Clear(void) {
    for (uint8_t i = 0; i < 4; i++) {
        displayDigits[i] = 11; // Vide
        dpState[i] = false;
    }
    SelectDigit(4);
}
