
/**
 * @file RJ_ELEKTRONIK_7SEG_4DIGI_STM32.c
 * @brief Implémentation du driver pour afficheur 7 segments 4 digits
 * @version 1.0
 * @date 2023
 * @copyright RJ Elektronik - Tous droits réservés
 */

#include "RJ_ELEKTRONIK_7SEG_4DIGI_STM32.h"
#include <stdbool.h>


// Variables globales pour stocker la configuration
static DisplayType displayType;          // Type d'affichage (cathode/anode commune)
static GPIO_TypeDef* segPort;            // Port GPIO pour les segments
static uint16_t segPins[8];              // Broches des segments [A,B,C,D,E,F,G,DP]
static GPIO_TypeDef* digitPort;          // Port GPIO pour les digits
static uint16_t digitPins[4];            // Broches des digits [DIG1-DIG4]

// Patterns pour les chiffres (cathode commune)
static const uint8_t digitPatterns[12] = {
    0b11000000, // 0 - Segments A,B,C,D,E,F allumés
    0b11111001, // 1 - Segments B,C allumés
    0b10100100, // 2 - Segments A,B,G,E,D allumés
    0b10110000, // 3 - Segments A,B,G,C,D allumés
    0b10011001, // 4 - Segments F,G,B,C allumés
    0b10010010, // 5 - Segments A,F,G,C,D allumés
    0b10000010, // 6 - Segments A,F,G,C,D,E allumés
    0b11111000, // 7 - Segments A,B,C allumés
    0b10000000, // 8 - Tous segments allumés
    0b10010000, // 9 - Segments A,B,C,D,F,G allumés
    0b10111111, // - - Segment G allumé (tiret)
    0b11111111  // Vide - Tous segments éteints
};

/**
 * @brief Affiche un chiffre sur les segments
 * @param digit Chiffre à afficher (0-11 où 10=- et 11=vide)
 */
static void DisplayDigit(uint8_t digit) {
    // Limite le chiffre à la plage valide
    digit = (digit > 11) ? 11 : digit;

    // Sélectionne le pattern selon le type d'affichage
    uint8_t pattern = (displayType == COMMON_CATHODE) ? digitPatterns[digit] : ~digitPatterns[digit];

    // Active/Désactive chaque segment selon le pattern
    HAL_GPIO_WritePin(segPort, segPins[0], (pattern & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET); // A
    HAL_GPIO_WritePin(segPort, segPins[1], (pattern & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET); // B
    HAL_GPIO_WritePin(segPort, segPins[2], (pattern & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET); // C
    HAL_GPIO_WritePin(segPort, segPins[3], (pattern & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET); // D
    HAL_GPIO_WritePin(segPort, segPins[4], (pattern & 0x10) ? GPIO_PIN_SET : GPIO_PIN_RESET); // E
    HAL_GPIO_WritePin(segPort, segPins[5], (pattern & 0x20) ? GPIO_PIN_SET : GPIO_PIN_RESET); // F
    HAL_GPIO_WritePin(segPort, segPins[6], (pattern & 0x40) ? GPIO_PIN_SET : GPIO_PIN_RESET); // G
}

/**
 * @brief Sélectionne un digit particulier
 * @param position Position du digit (0-3 correspondant à DIG1-DIG4)
 */
static void SelectDigit(uint8_t position) {
    // Désactive tous les digits
    for (uint8_t i = 0; i < 4; i++) {
        HAL_GPIO_WritePin(digitPort, digitPins[i],
                         (displayType == COMMON_CATHODE) ? GPIO_PIN_RESET : GPIO_PIN_SET);
    }

    // Active le digit sélectionné
    if (position < 4) {
        HAL_GPIO_WritePin(digitPort, digitPins[position],
                         (displayType == COMMON_CATHODE) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }
}

/**
 * @brief Initialise l'afficheur 7 segments
 * @param type Type d'affichage (COMMON_CATHODE ou COMMON_ANODE)
 * @param segPort_ Port GPIO pour les segments
 * @param segA à segDP Broches des segments A-G et point décimal
 * @param digitPort_ Port GPIO pour les digits
 * @param digit1 à digit4 Broches des digits 1 à 4
 */
void SevenSeg_Init(DisplayType type,
                  GPIO_TypeDef* segPort_, uint16_t segA, uint16_t segB, uint16_t segC,
                  uint16_t segD, uint16_t segE, uint16_t segF, uint16_t segG, uint16_t segDP,
                  GPIO_TypeDef* digitPort_, uint16_t digit1, uint16_t digit2,
                  uint16_t digit3, uint16_t digit4) {

    // Stockage de la configuration
    displayType = type;
    segPort = segPort_;
    digitPort = digitPort_;

    // Configuration des broches des segments
    segPins[0] = segA; // A
    segPins[1] = segB; // B
    segPins[2] = segC; // C
    segPins[3] = segD; // D
    segPins[4] = segE; // E
    segPins[5] = segF; // F
    segPins[6] = segG; // G
    segPins[7] = segDP; // DP

    // Configuration des broches des digits
    digitPins[0] = digit1; // DIG1
    digitPins[1] = digit2; // DIG2
    digitPins[2] = digit3; // DIG3
    digitPins[3] = digit4; // DIG4

    // Initialisation des GPIO
    GPIO_InitTypeDef gpio = {0};
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;

    // Configuration des broches des segments (A-G + DP)
    gpio.Pin = segA | segB | segC | segD | segE | segF | segG | segDP;
    HAL_GPIO_Init(segPort, &gpio);

    // Configuration des broches des digits (DIG1-DIG4)
    gpio.Pin = digit1 | digit2 | digit3 | digit4;
    HAL_GPIO_Init(digitPort, &gpio);

    // Efface l'affichage
    SevenSeg_Clear();
}

/**
 * @brief Affiche un nombre sur l'afficheur 7 segments
 * @param number Nombre à afficher (-999 à 9999)
 * @param point_on Active le point décimal si true
 * @param point_pos Position du point décimal (0-3)
 */
void SevenSeg_DisplayNumber(int16_t number, bool point_on, uint8_t point_pos) {
    uint8_t digits[4]; // Tableau pour stocker les chiffres à afficher

    // Gestion des nombres négatifs
    if (number < 0) {
        digits[0] = 10; // Affiche '-' sur le premier digit
        number = -number;
        if (number > 999) number = 999; // Limite à -999
        digits[1] = (number / 100) % 10;
        digits[2] = (number / 10) % 10;
        digits[3] = number % 10;
    }
    // Gestion des nombres trop grands
    else if (number > 9999) {
        for (uint8_t i = 0; i < 4; i++) digits[i] = 10; // Affiche '----'
    }
    // Nombre normal
    else {
        digits[0] = (number / 1000) % 10;
        digits[1] = (number / 100) % 10;
        digits[2] = (number / 10) % 10;
        digits[3] = number % 10;
    }

    // Affichage multiplexé
    for (uint8_t i = 0; i < 4; i++) {
        DisplayDigit(digits[i]);

        // Gestion du point décimal
        HAL_GPIO_WritePin(segPort, segPins[7], // segPins[7] = DP
            (point_on && (i == (point_pos % 4))) ?
            ((displayType == COMMON_CATHODE) ? GPIO_PIN_RESET : GPIO_PIN_SET) :
            ((displayType == COMMON_CATHODE) ? GPIO_PIN_SET : GPIO_PIN_RESET));

        SelectDigit(i);
        HAL_Delay(3); // Durée d'affichage par digit (3ms)
    }
}

/**
 * @brief Efface l'affichage (éteint tous les segments et digits)
 */
void SevenSeg_Clear(void) {
    // Éteint tous les segments
    uint8_t state = (displayType == COMMON_CATHODE) ? GPIO_PIN_RESET : GPIO_PIN_SET;
    for (uint8_t i = 0; i < 8; i++) { // 7 segments + DP
        HAL_GPIO_WritePin(segPort, segPins[i], state);
    }

    // Désactive tous les digits
    state = (displayType == COMMON_CATHODE) ? GPIO_PIN_RESET : GPIO_PIN_SET;
    for (uint8_t i = 0; i < 4; i++) {
        HAL_GPIO_WritePin(digitPort, digitPins[i], state);
    }
}
