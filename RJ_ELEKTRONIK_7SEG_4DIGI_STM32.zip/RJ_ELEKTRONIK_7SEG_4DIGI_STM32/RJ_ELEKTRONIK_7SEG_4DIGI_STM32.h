/**
 * @file RJ_ELEKTRONIK_7SEG_4DIGI_STM32.h
 * @brief Driver pour afficheur 7 segments 4 digits
 * @version 1.0
 * @date 2023
 * @copyright RJ Elektronik - Tous droits réservés
 */



#ifndef RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H_
#define RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H_

#include "stm32f1xx_hal.h"
#include <stdbool.h>


typedef enum {
    COMMON_CATHODE,  // Affichage à cathode commune
    COMMON_ANODE     // Affichage à anode commune
} DisplayType;

// Prototypes des fonctions
void SevenSeg_Init(DisplayType type, GPIO_TypeDef* segPort, uint16_t segA, uint16_t segB, uint16_t segC,
                  uint16_t segD, uint16_t segE, uint16_t segF, uint16_t segG, uint16_t segDP,
                  GPIO_TypeDef* digitPort, uint16_t digit1, uint16_t digit2, uint16_t digit3, uint16_t digit4);
void SevenSeg_DisplayNumber(int16_t number, bool point_on, uint8_t point_pos);
void SevenSeg_Clear(void);

#endif
