/* * PORT_SERIAL_DEBUG_RJ-ELEKTRONIK.h * * Created on: 15 mai 2026 * Author: RENATYJERRY */
#ifndef INC_PORT_SERIAL_DEBUG_RJ_ELEKTRONIK_H_
#define INC_PORT_SERIAL_DEBUG_RJ_ELEKTRONIK_H_

#include "main.h"

/* ==================================================================== */
/* CONFIGURATION DU CANAL DE DEBUG                                      */
/* ==================================================================== */
#define DEBUG_CHANNEL_USB      0
#define DEBUG_CHANNEL_UART     1

// Choisissez votre mode de debug ici
#define DEBUG_INTERFACE_SELECT   DEBUG_CHANNEL_USB

// Configuration de la vitesse USB (1 = High Speed, 0 = Full Speed)
#define USB_SPEED_HIGH           0
/* ==================================================================== */

#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_USB)
  #include "usbd_cdc_if.h"

  #if (USB_SPEED_HIGH == 1)
    #define USB_TRANSMIT_FUNC  CDC_Transmit_HS
  #else
    #define USB_TRANSMIT_FUNC  CDC_Transmit_FS
  #endif
#endif

/* Configurations générales de la bibliothèque */
#define VCP_RX_BUFFER_SIZE 512

/* Prototypes des fonctions publiques */
#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_USB)
  void Serial_debug_RJ(void);
#else
  void Serial_debug_RJ(UART_HandleTypeDef *huart, uint32_t baudrate);
#endif

int16_t debug_print(const char *str);
int16_t Serial_WriteData(const uint8_t *pdata, uint16_t size);
uint16_t Serial_GetRxDataSize(void);
uint16_t Serial_ReadData(uint8_t *pdest, uint16_t max_size);
void Serial_ClearRxBuffer(void);

/* Fonction de callback pour l'interruption (USB ou UART) */
void Serial_Receive_Callback(uint8_t *Buf, uint32_t len);

#endif /* INC_PORT_SERIAL_DEBUG_RJ_ELEKTRONIK_H_ */
