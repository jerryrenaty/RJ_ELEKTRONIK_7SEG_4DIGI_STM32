/* * PORT_SERIAL_DEBUG_RJ-ELEKTRONIK.c * * Created on: 15 mai 2026 * Author: RENATYJERRY */
#include "PORT_SERIAL_DEBUG_RJ-ELEKTRONIK.h"
#include <string.h>

/* Variables statiques internes pour le tampon circulaire de réception */
static uint8_t vcp_rx_ring_buffer[VCP_RX_BUFFER_SIZE];
static volatile uint16_t vcp_rx_head = 0;
static volatile uint16_t vcp_rx_tail = 0;

#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_UART)
  static UART_HandleTypeDef *static_huart = NULL;
  static uint8_t uart_rx_byte; // Stockage intermédiaire pour l'interruption UART
#endif

/* Initialisation avec modification dynamique du Baudrate */
#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_USB)
void Serial_debug_RJ(void) {
    vcp_rx_head = 0;
    vcp_rx_tail = 0;
    memset(vcp_rx_ring_buffer, 0, VCP_RX_BUFFER_SIZE);
}
#else
void Serial_debug_RJ(UART_HandleTypeDef *huart, uint32_t baudrate) {
    vcp_rx_head = 0;
    vcp_rx_tail = 0;
    memset(vcp_rx_ring_buffer, 0, VCP_RX_BUFFER_SIZE);
    static_huart = huart;

    if (static_huart != NULL) {
        // Désactivation temporaire pour appliquer les modifications
        HAL_UART_DeInit(static_huart);

        // Injection dynamique de la nouvelle vitesse demandée
        static_huart->Init.BaudRate = baudrate;

        // Ré-initialisation matérielle avec la nouvelle configuration
        if (HAL_UART_Init(static_huart) == HAL_OK) {
            // Démarre la réception UART par interruption (1 octet à la fois)
            HAL_UART_Receive_IT(static_huart, &uart_rx_byte, 1);
        }
    }
}
#endif

/* Envoi d'une chaîne de caractères (style texte/debug) */
int16_t debug_print(const char *str) {
    return Serial_WriteData((const uint8_t*)str, strlen(str));
}

/* Envoi de données brutes avec gestion de l'interface active */
int16_t Serial_WriteData(const uint8_t *pdata, uint16_t size) {
    if (pdata == NULL || size == 0) return -1;

#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_USB)
    uint32_t timeout_counter = 0;
    uint8_t result;
    do {
        result = USB_TRANSMIT_FUNC((uint8_t*)pdata, size);
        if (result == USBD_OK) return 0;

        // Évite le freeze si appelé depuis une interruption prioritaire
        HAL_Delay(1);
        timeout_counter++;
        if (timeout_counter > 50) return -2; // Timeout 50ms
    } while (result == USBD_BUSY);
    return -3;
#else
    if (static_huart == NULL) return -1;
    // Envoi via l'UART configuré (Bloquant avec timeout de 100ms)
    if (HAL_UART_Transmit(static_huart, (uint8_t*)pdata, size, 100) == HAL_OK) {
        return 0;
    }
    return -4; // Erreur matérielle UART
#endif
}

/* Récupère le nombre d'octets actuellement en attente de lecture */
uint16_t Serial_GetRxDataSize(void) {
    uint16_t head, tail;

    // Lecture sécurisée des variables volatiles
    __disable_irq();
    head = vcp_rx_head;
    tail = vcp_rx_tail;
    __enable_irq();

    if (head >= tail) {
        return (head - tail);
    } else {
        return (VCP_RX_BUFFER_SIZE - tail + head);
    }
}

/* Lit les données reçues et les copie vers un tampon utilisateur */
uint16_t Serial_ReadData(uint8_t *pdest, uint16_t max_size) {
    uint16_t bytes_read = 0;
    while ((vcp_rx_tail != vcp_rx_head) && (bytes_read < max_size)) {
        pdest[bytes_read++] = vcp_rx_ring_buffer[vcp_rx_tail];
        vcp_rx_tail = (vcp_rx_tail + 1) % VCP_RX_BUFFER_SIZE;
    }
    return bytes_read;
}

/* Réinitialise proprement le tampon de réception */
void Serial_ClearRxBuffer(void) {
    __disable_irq();
    vcp_rx_tail = vcp_rx_head;
    __enable_irq();
}

/* Callback générique d'interruption (USB ou UART) */
void Serial_Receive_Callback(uint8_t *Buf, uint32_t len) {
    for (uint32_t i = 0; i < len; i++) {
        uint16_t next_head = (vcp_rx_head + 1) % VCP_RX_BUFFER_SIZE;
        if (next_head != vcp_rx_tail) {
            vcp_rx_ring_buffer[vcp_rx_head] = Buf[i];
            vcp_rx_head = next_head;
        } else {
            break; // Tampon plein
        }
    }
}

/* Interruption UART native de ST : Reroutage vers notre callback circulaire */
#if (DEBUG_INTERFACE_SELECT == DEBUG_CHANNEL_UART)
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart == static_huart) {
        Serial_Receive_Callback(&uart_rx_byte, 1);
        HAL_UART_Receive_IT(static_huart, &uart_rx_byte, 1);
    }
}
#endif
