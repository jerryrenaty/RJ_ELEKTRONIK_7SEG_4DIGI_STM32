#ifndef RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H
#define RJ_ELEKTRONIK_7SEG_4DIGI_STM32_H

#include "main.h" // Obligatoire pour récupérer les types GPIO_TypeDef, HAL, etc.
#include <stdbool.h>
#include <stdint.h>

// Définition de vos broches (Copie conforme de vos CubeMX defines)
#define G_Pin GPIO_PIN_15
#define G_GPIO_Port GPIOB
#define F_Pin GPIO_PIN_8
#define F_GPIO_Port GPIOD
#define E_Pin GPIO_PIN_9
#define E_GPIO_Port GPIOD
#define D_Pin GPIO_PIN_10
#define D_GPIO_Port GPIOD
#define C_Pin GPIO_PIN_11
#define C_GPIO_Port GPIOD
#define B_Pin GPIO_PIN_12
#define B_GPIO_Port GPIOD
#define A_Pin GPIO_PIN_13
#define A_GPIO_Port GPIOD

#define D4_Pin GPIO_PIN_15
#define D4_GPIO_Port GPIOD
#define D3_Pin GPIO_PIN_6
#define D3_GPIO_Port GPIOC
#define D2_Pin GPIO_PIN_7
#define D2_GPIO_Port GPIOC
#define D1_Pin GPIO_PIN_8
#define D1_GPIO_Port GPIOC

// Le point décimal n'étant pas défini dans votre liste, on le désactive par défaut (ou mettez une broche inutilisée)
#define DP_Pin GPIO_PIN_0
#define DP_GPIO_Port GPIOA

typedef enum {
    COMMON_CATHODE,
    COMMON_ANODE
} DisplayType;

// Fonctions publiques simplifiées
void SevenSeg_Init(DisplayType type);
void SevenSeg_UpdateNumber(int16_t number, bool point_on, uint8_t point_pos);
void SevenSeg_Mux_Callback(void);
void SevenSeg_Clear(void);

#endif
